# libs/app/services/pack_view.py — SQLAlchemy 2.x clean drop-in
from __future__ import annotations
import sqlalchemy as sa
from math import ceil
from typing import Dict, List, Optional, Tuple, Any

from sqlalchemy import Select, and_, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session


from backend.db.models import (
    Order,
    OrderLine,
    Pack,
    PackBox,
    PackBoxItem,
    PairGuard,
    CartonType,
)


# ---------- Public API ----------

def get_pack_snapshot(db: Session, pack_id: int) -> Dict:
    """Builds a read model for the Pack workspace (box numbers, dims for custom+catalog)."""
    pack = db.get(Pack, pack_id)
    if not pack:
        raise ValueError(f"Pack {pack_id} not found")

    order: Optional[Order] = pack.order
    if not order:
        raise ValueError(
            f"Pack {pack_id} references missing Order {pack.order_id}. Create a new pack from Orders."
        )

    # ---------- Lines with packed/remaining ----------
    qty_sq = (
        select(
            PackBoxItem.order_line_id.label("order_line_id"),
            func.coalesce(func.sum(PackBoxItem.qty), 0).label("packed_qty"),
        )
        .join(PackBox, PackBox.id == PackBoxItem.pack_box_id)
        .where(PackBox.pack_id == pack_id)
        .group_by(PackBoxItem.order_line_id)
        .subquery()
    )

    line_stmt = (
        select(
            OrderLine.id,
            OrderLine.product_code,
            OrderLine.length_in,
            OrderLine.height_in,
            OrderLine.finish,
            OrderLine.qty_ordered,
            func.coalesce(qty_sq.c.packed_qty, 0).label("packed_qty"),
        )
        .outerjoin(qty_sq, qty_sq.c.order_line_id == OrderLine.id)
        .where(OrderLine.order_id == order.id)
        .order_by(OrderLine.product_code)
    )
    line_rows = db.execute(line_stmt).all()

    lines: List[Dict] = []
    for r in line_rows:
        m = r._mapping
        qty_ordered = int(m["qty_ordered"] or 0)
        packed_qty = int(m["packed_qty"] or 0)
        remaining = max(0, qty_ordered - packed_qty)
        lines.append(
            {
                "id": m["id"],
                "product_code": m["product_code"],
                "finish": m["finish"],
                "length_in": m["length_in"],
                "height_in": m["height_in"],
                "qty_ordered": qty_ordered,
                "packed_qty": packed_qty,
                "remaining": remaining,
            }
        )

    # ---------- Boxes (include box_no and dims for custom+catalog) ----------
    # Pull PackBox plus CartonType dims if carton_type_id is set.
    box_stmt = (
        select(
            PackBox.id,
            PackBox.box_no,                       # per-order number
            PackBox.weight_lbs,
            PackBox.custom_l_in,
            PackBox.custom_w_in,
            PackBox.custom_h_in,
            PackBox.carton_type_id,
            CartonType.length_in.label("ct_length_in"),
            CartonType.width_in.label("ct_width_in"),
            CartonType.height_in.label("ct_height_in"),
            CartonType.name.label("ct_name"),
        )
        .outerjoin(CartonType, CartonType.id == PackBox.carton_type_id)
        .where(PackBox.pack_id == pack_id)
        .order_by(func.coalesce(PackBox.box_no, 2147483647), PackBox.id)  # prefer box_no, then id
    )
    box_rows = db.execute(box_stmt).all()
    box_ids = [int(r._mapping["id"]) for r in box_rows]

    # Batch fetch items (no N+1) and include product_code via join
    items_by_box: Dict[int, List[Dict]] = {bid: [] for bid in box_ids}
    if box_ids:
        items_stmt = (
            select(
                PackBoxItem.id,
                PackBoxItem.pack_box_id,
                PackBoxItem.order_line_id,
                PackBoxItem.qty,
                OrderLine.product_code,
            )
            .join(OrderLine, OrderLine.id == PackBoxItem.order_line_id)
            .where(PackBoxItem.pack_box_id.in_(box_ids))
            .order_by(PackBoxItem.id)
        )
        for ir in db.execute(items_stmt).all():
            im = ir._mapping
            items_by_box[int(im["pack_box_id"])].append(
                {
                    "id": im["id"],
                    "order_line_id": im["order_line_id"],
                    "product_code": im["product_code"],
                    "qty": int(im["qty"] or 0),
                }
            )

    boxes: List[Dict] = []
    for b in box_rows:
        bm = b._mapping
        # Choose dims: prefer custom; else catalog dims
        Lc, Wc, Hc = bm["custom_l_in"], bm["custom_w_in"], bm["custom_h_in"]
        if Lc is not None and Wc is not None and Hc is not None:
            L, W, H = int(Lc), int(Wc), int(Hc)
        else:
            L = int(bm["ct_length_in"]) if bm["ct_length_in"] is not None else None
            W = int(bm["ct_width_in"]) if bm["ct_width_in"] is not None else None
            H = int(bm["ct_height_in"]) if bm["ct_height_in"] is not None else None

        # Build label: "Box {box_no}" if present, else "Box #{id}", always append dims when known
        base_label = f'Box {int(bm["box_no"])}' if bm["box_no"] is not None else f'Box #{bm["id"]}'
        if L is not None and W is not None and H is not None:
            label = f"{base_label} ({L}x{W}x{H} in)"
        else:
            label = base_label

        boxes.append(
            {
                "id": bm["id"],
                "box_no": int(bm["box_no"]) if bm["box_no"] is not None else None,
                "label": label,
                "weight_lbs": bm["weight_lbs"],
                # expose dims so the UI can reuse them if needed
                "custom_l_in": int(Lc) if Lc is not None else None,
                "custom_w_in": int(Wc) if Wc is not None else None,
                "custom_h_in": int(Hc) if Hc is not None else None,
                "length_in": L,
                "width_in": W,
                "height_in": H,
                "carton_type_id": int(bm["carton_type_id"]) if bm["carton_type_id"] is not None else None,
                "carton_name": bm["ct_name"],
                "items": items_by_box.get(int(bm["id"]), []),
            }
        )

    header = {
        "order_no": order.order_no,
        "customer_name": order.customer_name,
        "due_date": str(order.due_date) if order.due_date else None,
        "lead_time_plan": order.lead_time_plan,
        "ship_to": order.ship_to,
        "status": pack.status,
    }
    return {"header": header, "lines": lines, "boxes": boxes}


def add_empty_box(db: Session, pack_id: int) -> int:
    pack = db.get(Pack, pack_id)
    if not pack:
        raise ValueError("Pack not found")
    box = PackBox(pack_id=pack_id)
    db.add(box)
    db.commit()
    return int(box.id)


def assign_one(db: Session, pack_id: int, order_line_id: int, box_id: int) -> None:
    _validate_pack_box_line(db, pack_id, box_id, order_line_id)

    remaining = _remaining_for_line(db, pack_id, order_line_id, exclude_box_id=None)
    if remaining <= 0:
        raise ValueError("No remaining quantity to assign")

    existing = db.execute(
        select(PackBoxItem).where(
            PackBoxItem.pack_box_id == box_id,
            PackBoxItem.order_line_id == order_line_id,
        )
    ).scalar_one_or_none()

    if existing is None:
        _enforce_pair_rule_on_add(db, pack_id, box_id, order_line_id)

    if existing:
        existing.qty = int(existing.qty) + 1
    else:
        db.add(PackBoxItem(pack_box_id=box_id, order_line_id=order_line_id, qty=1))

    db.commit()


def assign_up_to(db: Session, pack_id: int, order_line_id: int, box_id: int, qty: int) -> int:
    """Assign up to `qty` units while respecting remaining qty and pair rule. Returns actual added (0..qty)."""
    if qty <= 0:
        return 0

    _validate_pack_box_line(db, pack_id, box_id, order_line_id)

    remaining = _remaining_for_line(db, pack_id, order_line_id, exclude_box_id=None)
    if remaining <= 0:
        return 0

    to_add = min(int(qty), int(remaining))

    existing = db.execute(
        select(PackBoxItem).where(
            PackBoxItem.pack_box_id == box_id,
            PackBoxItem.order_line_id == order_line_id,
        )
    ).scalar_one_or_none()

    if existing is None and to_add > 0:
        _enforce_pair_rule_on_add(db, pack_id, box_id, order_line_id)

    if to_add == 0:
        return 0

    if existing:
        existing.qty = int(existing.qty) + to_add
    else:
        db.add(PackBoxItem(pack_box_id=box_id, order_line_id=order_line_id, qty=to_add))

    db.commit()
    return to_add


def set_qty(db: Session, pack_id: int, box_id: int, order_line_id: int, qty: int) -> None:
    if qty < 0:
        raise ValueError("Quantity cannot be negative")

    _validate_pack_box_line(db, pack_id, box_id, order_line_id)

    other_sum = _packed_in_pack_excluding_box(db, pack_id, order_line_id, box_id)
    line = db.get(OrderLine, order_line_id)
    if not line:
        raise ValueError("Order line not found")
    ordered = int(line.qty_ordered)

    if other_sum + qty > ordered:
        raise ValueError(f"Exceeds ordered qty ({ordered}); currently {other_sum} in other boxes")

    existing = db.execute(
        select(PackBoxItem).where(
            PackBoxItem.pack_box_id == box_id,
            PackBoxItem.order_line_id == order_line_id,
        )
    ).scalar_one_or_none()

    if existing is None and qty > 0:
        _enforce_pair_rule_on_add(db, pack_id, box_id, order_line_id)

    if qty == 0:
        if existing:
            db.delete(existing)
    else:
        if existing:
            existing.qty = int(qty)
        else:
            db.add(PackBoxItem(pack_box_id=box_id, order_line_id=order_line_id, qty=int(qty)))

    db.commit()


def remove_box_item(db: Session, pack_id: int, box_item_id: int) -> None:
    item = db.get(PackBoxItem, box_item_id)
    if not item:
        return
    box = db.get(PackBox, item.pack_box_id)
    if not box or box.pack_id != pack_id:
        raise ValueError("Item does not belong to this pack")
    db.delete(item)
    db.commit()


def delete_box_if_empty(db: Session, pack_id: int, box_id: int) -> None:
    box = db.get(PackBox, box_id)
    if not box or box.pack_id != pack_id:
        raise ValueError("Box not found in this pack")
    count_stmt = select(func.count()).select_from(PackBoxItem).where(PackBoxItem.pack_box_id == box_id)
    count = db.execute(count_stmt).scalar_one()
    if count and int(count) > 0:
        raise ValueError("Cannot delete a non-empty box")
    db.delete(box)
    db.commit()


def set_box_weight_lbs(db: Session, pack_id: int, box_id: int, weight_lbs: int | float | None) -> Optional[int]:
    box = db.get(PackBox, box_id)
    if not box or box.pack_id != pack_id:
        raise ValueError("Box not found in this pack")

    if weight_lbs is None:
        box.weight_lbs = None
        db.commit()
        return None

    rounded = int(ceil(float(weight_lbs)))
    if box.carton_type_id:
        ct = db.get(CartonType, box.carton_type_id)
        if ct and ct.max_weight_lb is not None and rounded > int(ct.max_weight_lb):
            raise ValueError(f"Weight exceeds carton max ({ct.max_weight_lb} lbs)")
    box.weight_lbs = rounded
    db.commit()
    return rounded

# ---------- Internal helpers ----------

def _validate_pack_box_line(db: Session, pack_id: int, box_id: int, order_line_id: int) -> None:
    pack = db.get(Pack, pack_id)
    if not pack:
        raise ValueError("Pack not found")
    box = db.get(PackBox, box_id)
    if not box or box.pack_id != pack_id:
        raise ValueError("Box not found in this pack")
    line = db.get(OrderLine, order_line_id)
    if not line or line.order_id != pack.order_id:
        raise ValueError("Line does not belong to order for this pack")


def _remaining_for_line(db: Session, pack_id: int, order_line_id: int, exclude_box_id: Optional[int]) -> int:
    stmt = (
        select(func.coalesce(func.sum(PackBoxItem.qty), 0))
        .join(PackBox, PackBox.id == PackBoxItem.pack_box_id)
        .where(PackBox.pack_id == pack_id, PackBoxItem.order_line_id == order_line_id)
    )
    if exclude_box_id is not None:
        stmt = stmt.where(PackBoxItem.pack_box_id != exclude_box_id)
    packed = int(db.execute(stmt).scalar_one() or 0)

    line = db.get(OrderLine, order_line_id)
    if not line:
        raise ValueError("Order line not found")
    ordered = int(line.qty_ordered)
    return max(0, ordered - packed)


def _packed_in_pack_excluding_box(db: Session, pack_id: int, order_line_id: int, exclude_box_id: int) -> int:
    stmt = (
        select(func.coalesce(func.sum(PackBoxItem.qty), 0))
        .join(PackBox, PackBox.id == PackBoxItem.pack_box_id)
        .where(
            PackBox.pack_id == pack_id,
            PackBoxItem.order_line_id == order_line_id,
            PackBoxItem.pack_box_id != exclude_box_id,
        )
    )
    return int(db.execute(stmt).scalar_one() or 0)


def _box_distinct_line_ids(db: Session, box_id: int) -> List[int]:
    stmt = (
        select(PackBoxItem.order_line_id)
        .where(PackBoxItem.pack_box_id == box_id)
        .group_by(PackBoxItem.order_line_id)
    )
    return [int(r[0]) for r in db.execute(stmt).all()]


def _box_id_with_pair_elsewhere(db: Session, pack_id: int, exclude_box_id: int, a_line_id: int, b_line_id: int) -> Optional[int]:
    # Boxes in this pack that already contain BOTH a and b (distinct lines)
    stmt = (
        select(PackBoxItem.pack_box_id)
        .join(PackBox, PackBox.id == PackBoxItem.pack_box_id)
        .where(PackBox.pack_id == pack_id, PackBoxItem.order_line_id.in_([a_line_id, b_line_id]))
        .group_by(PackBoxItem.pack_box_id)
        .having(func.count(func.distinct(PackBoxItem.order_line_id)) == 2)
    )
    for row in db.execute(stmt).all():
        bid = int(row._mapping["pack_box_id"]) if "pack_box_id" in row._mapping else int(row[0])
        if bid != exclude_box_id:
            return bid
    return None


def _enforce_pair_rule_on_add(db: Session, pack_id: int, dest_box_id: int, new_line_id: int) -> None:
    present = _box_distinct_line_ids(db, dest_box_id)
    if not present:
        return

    pack = db.get(Pack, pack_id)
    if not pack:
        raise ValueError("Pack not found")
    order_id = int(pack.order_id)

    codes: Dict[int, str] = {}
    for ln_id in present:
        if ln_id == new_line_id:
            continue
        other_box_id = _box_id_with_pair_elsewhere(db, pack_id, dest_box_id, ln_id, new_line_id)
        if other_box_id is not None:
            if ln_id not in codes:
                ol = db.get(OrderLine, ln_id)
                codes[ln_id] = ol.product_code if ol else str(ln_id)
            if new_line_id not in codes:
                ol = db.get(OrderLine, new_line_id)
                codes[new_line_id] = ol.product_code if ol else str(new_line_id)
            raise ValueError(
                f"Pair rule: {codes.get(ln_id, ln_id)} + {codes.get(new_line_id, new_line_id)} already together in Box #{other_box_id}"
            )
        try:
            a, b = sorted((int(ln_id), int(new_line_id)))
            db.add(PairGuard(order_id=order_id, line_a_id=a, line_b_id=b))
            db.flush()
        except IntegrityError:
            db.rollback()
            # Guard already exists; fine.
