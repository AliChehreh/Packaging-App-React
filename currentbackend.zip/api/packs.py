from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field

from backend.deps import get_app_db

router = APIRouter()


# ---------- Request models (minimal for now) ----------
class AssignOneBody(BaseModel):
    order_line_id: int = Field(..., gt=0)

class AssignUpToBody(BaseModel):
    order_line_id: int = Field(..., gt=0)
    qty: int = Field(..., gt=0)

class SetQtyBody(BaseModel):
    order_line_id: int = Field(..., gt=0)
    qty: int = Field(..., ge=0)

class RemoveItemBody(BaseModel):
    order_line_id: int = Field(..., gt=0)

class SetWeightBody(BaseModel):
    weight_lbs: float = Field(..., ge=0)


def _svc_import():
    """
    Lazy-import the service layer so this module can load
    even before we copy the implementation in the next step.
    """
    try:
        from backend.services.pack_view import (
            get_pack_snapshot,
            add_empty_box,
            assign_one,
            assign_up_to,
            set_qty,
            remove_box_item,
            delete_box_if_empty,
            set_box_weight_lbs,
        )
        return {
            "get_pack_snapshot": get_pack_snapshot,
            "add_empty_box": add_empty_box,
            "assign_one": assign_one,
            "assign_up_to": assign_up_to,
            "set_qty": set_qty,
            "remove_box_item": remove_box_item,
            "delete_box_if_empty": delete_box_if_empty,
            "set_box_weight_lbs": set_box_weight_lbs,
        }
    except Exception as e:
        raise HTTPException(
            status_code=503,
            detail=f"Pack service not wired yet. Complete Step 8. ({e})"
        )


# ---------- Endpoints ----------
@router.get("/packs/{pack_id}/snapshot")
def get_snapshot(pack_id: int, db: Session = Depends(get_app_db)):
    svc = _svc_import()
    return svc["get_pack_snapshot"](db, pack_id)


@router.post("/packs/{pack_id}/boxes")
def create_empty_box(pack_id: int, db: Session = Depends(get_app_db)):
    svc = _svc_import()
    box_id = svc["add_empty_box"](db, pack_id)
    return {"box_id": box_id, "snapshot": svc["get_pack_snapshot"](db, pack_id)}


@router.post("/packs/{pack_id}/boxes/{box_id}/assign-one")
def assign_one_item(pack_id: int, box_id: int, body: AssignOneBody, db: Session = Depends(get_app_db)):
    svc = _svc_import()
    svc["assign_one"](db, pack_id, body.order_line_id, box_id)
    return svc["get_pack_snapshot"](db, pack_id)


@router.post("/packs/{pack_id}/boxes/{box_id}/assign-up-to")
def assign_up_to_qty(pack_id: int, box_id: int, body: AssignUpToBody, db: Session = Depends(get_app_db)):
    svc = _svc_import()
    added = svc["assign_up_to"](db, pack_id, body.order_line_id, box_id, body.qty)
    return {"added": added, "snapshot": svc["get_pack_snapshot"](db, pack_id)}


@router.put("/packs/{pack_id}/boxes/{box_id}/set-qty")
def set_box_item_qty(pack_id: int, box_id: int, body: SetQtyBody, db: Session = Depends(get_app_db)):
    svc = _svc_import()
    svc["set_qty"](db, pack_id, body.order_line_id, box_id, body.qty)
    return svc["get_pack_snapshot"](db, pack_id)


@router.delete("/packs/{pack_id}/boxes/{box_id}/items")
def remove_item(pack_id: int, box_id: int, body: RemoveItemBody, db: Session = Depends(get_app_db)):
    svc = _svc_import()
    svc["remove_box_item"](db, pack_id, body.order_line_id, box_id)
    return svc["get_pack_snapshot"](db, pack_id)


@router.delete("/packs/{pack_id}/boxes/{box_id}")
def delete_box(pack_id: int, box_id: int, db: Session = Depends(get_app_db)):
    svc = _svc_import()
    svc["delete_box_if_empty"](db, pack_id, box_id)
    return svc["get_pack_snapshot"](db, pack_id)


@router.put("/packs/{pack_id}/boxes/{box_id}/weight")
def set_weight(pack_id: int, box_id: int, body: SetWeightBody, db: Session = Depends(get_app_db)):
    svc = _svc_import()
    svc["set_box_weight_lbs"](db, pack_id, box_id, body.weight_lbs)
    return svc["get_pack_snapshot"](db, pack_id)
