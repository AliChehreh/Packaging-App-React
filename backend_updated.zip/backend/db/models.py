
from datetime import datetime, date
from sqlalchemy import (
    Integer, String, Date, DateTime, Enum, ForeignKey, UniqueConstraint,
    CheckConstraint
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from backend.db.session import AppBase as Base
import enum

class Role(str, enum.Enum):
    packager = "packager"
    supervisor = "supervisor"

class User(Base):
    __tablename__ = "user"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[Role] = mapped_column(Enum(Role), default=Role.packager)
    active: Mapped[int] = mapped_column(Integer, default=1)

class CartonType(Base):
    __tablename__ = "carton_type"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(64), unique=True)
    inner_l_in: Mapped[int] = mapped_column(Integer)
    inner_w_in: Mapped[int] = mapped_column(Integer)
    inner_h_in: Mapped[int] = mapped_column(Integer)
    max_weight_lbs: Mapped[int | None] = mapped_column(Integer, nullable=True)

class ProductPackagingProfile(Base):
    __tablename__ = "product_packaging_profile"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    product_code: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    depth_in: Mapped[int] = mapped_column(Integer)
    length_mod_in: Mapped[int] = mapped_column(Integer, default=0)
    height_mod_in: Mapped[int] = mapped_column(Integer, default=0)
    updated_by: Mapped[int | None] = mapped_column(ForeignKey("user.id"), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Order(Base):
    __tablename__ = "order"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_no: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    customer_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    due_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    lead_time_plan: Mapped[str | None] = mapped_column(String(64), nullable=True)
    ship_to: Mapped[str | None] = mapped_column(String(255), nullable=True)
    source: Mapped[str] = mapped_column(String(16), default="OES")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    lines: Mapped[list["OrderLine"]] = relationship(back_populates="order", cascade="all, delete-orphan")

class OrderLine(Base):
    __tablename__ = "order_line"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("order.id", ondelete="CASCADE"), index=True, nullable=False)
    product_code: Mapped[str] = mapped_column(String(64), index=True)
    length_in: Mapped[int] = mapped_column(Integer)
    height_in: Mapped[int] = mapped_column(Integer)
    finish: Mapped[str | None] = mapped_column(String(64), nullable=True)
    qty_ordered: Mapped[int] = mapped_column(Integer)
    order: Mapped["Order"] = relationship(back_populates="lines")

class Pack(Base):
    __tablename__ = "pack"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("order.id", ondelete="CASCADE"), index=True, nullable=False)
    status: Mapped[str] = mapped_column(String(16), default="in_progress")
    started_by: Mapped[int | None] = mapped_column(ForeignKey("user.id"), nullable=True)
    completed_by: Mapped[int | None] = mapped_column(ForeignKey("user.id"), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    order: Mapped["Order"] = relationship("Order", backref="packs")

class PackBox(Base):
    __tablename__ = "pack_box"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    pack_id: Mapped[int] = mapped_column(ForeignKey("pack.id", ondelete="CASCADE"), index=True, nullable=False)
    carton_type_id: Mapped[int | None] = mapped_column(ForeignKey("carton_type.id"), nullable=True)
    custom_l_in: Mapped[int | None] = mapped_column(Integer, nullable=True)
    custom_w_in: Mapped[int | None] = mapped_column(Integer, nullable=True)
    custom_h_in: Mapped[int | None] = mapped_column(Integer, nullable=True)
    weight_lbs: Mapped[int | None] = mapped_column(Integer, nullable=True)
    pack: Mapped["Pack"] = relationship("Pack", backref="boxes")

class PackBoxItem(Base):
    __tablename__ = "pack_box_item"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    pack_box_id: Mapped[int] = mapped_column(ForeignKey("pack_box.id", ondelete="CASCADE"), index=True, nullable=False)
    order_line_id: Mapped[int] = mapped_column(ForeignKey("order_line.id"), index=True, nullable=False)
    qty: Mapped[int] = mapped_column(Integer)
    __table_args__ = (CheckConstraint("qty >= 0", name="ck_pbi_qty_nonneg"),)
    pack_box: Mapped["PackBox"] = relationship("PackBox", backref="items")
    order_line: Mapped["OrderLine"] = relationship("OrderLine")

class PackLineOverride(Base):
    __tablename__ = "pack_line_override"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    pack_id: Mapped[int] = mapped_column(ForeignKey("pack.id", ondelete="CASCADE"), index=True, nullable=False)
    order_line_id: Mapped[int] = mapped_column(ForeignKey("order_line.id"), index=True, nullable=False)
    depth_in: Mapped[int] = mapped_column(Integer)
    length_mod_in: Mapped[int] = mapped_column(Integer, default=0)
    height_mod_in: Mapped[int] = mapped_column(Integer, default=0)
    __table_args__ = (UniqueConstraint("pack_id", "order_line_id", name="uq_pack_line_override"),)

class PairGuard(Base):
    __tablename__ = "pair_guard"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("order.id", ondelete="CASCADE"), index=True, nullable=False)
    line_a_id: Mapped[int] = mapped_column(ForeignKey("order_line.id"), nullable=False)
    line_b_id: Mapped[int] = mapped_column(ForeignKey("order_line.id"), nullable=False)
    __table_args__ = (
        UniqueConstraint("order_id", "line_a_id", "line_b_id", name="uq_pair_guard"),
        CheckConstraint("line_a_id < line_b_id", name="ck_pair_guard_order"),
    )
