
from collections.abc import Generator
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base, Session
from backend.core.config import get_settings

settings = get_settings()

AppBase = declarative_base()
OesBase = declarative_base()

app_engine = create_engine(str(settings.APP_DATABASE_URL), pool_pre_ping=True, future=True)
oes_engine = create_engine(str(settings.OES_DATABASE_URL), pool_pre_ping=True, future=True)

AppSessionLocal = sessionmaker(bind=app_engine, autoflush=False, autocommit=False, future=True)

def get_app_session() -> Generator[Session, None, None]:
    db = AppSessionLocal()
    try:
        yield db
    finally:
        db.close()
