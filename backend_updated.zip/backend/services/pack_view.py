
from __future__ import annotations
from math import ceil
from typing import Dict, List, Optional

from sqlalchemy import select, func
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

from backend.db.models import (
    Order,
    OrderLine,
    Pack,
    PackBox,
    PackBoxItem,
    PairGuard,
    CartonType,
)

# ---------- Public API ----------

def get_pack_snapshot(db: Session, pack_id: int) -> Dict:
    pack = db.get(Pack, pack_id)
    if not pack:
        raise ValueError(f"Pack {pack_id} not found")

    order: Optional[Order] = pack.order
    if not order:
        raise ValueError(f"Pack {pack_id} references missing Order {pack.order_id}. Create a new pack from Orders.")

    qty_subq = (
        select(
            PackBoxItem.order_line_id,
            func.coalesce(func.sum(PackBoxItem.qty), 0).label("packed_qty"),
        )
        .join(PackBox, PackBox.id == PackBoxItem.pack_box_id)
        .where(PackBox.pack_id == pack_id)
        .group_by(PackBoxItem.order_line_id)
        .subquery()
    )

    rows = db.execute(
        select(
            OrderLine.id,
            OrderLine.product_code,
            OrderLine.length_in,
            OrderLine.height_in,
            OrderLine.finish,
            OrderLine.qty_ordered,
            func.coalesce(qty_subq.c.packed_qty, 0).label("packed_qty"),
        )
        .outerjoin(qty_subq, qty_subq.c.order_line_id == OrderLine.id)
        .where(OrderLine.order_id == order.id)
        .order_by(OrderLine.product_code)
    ).all()

    lines: List[Dict] = []
    for r in rows:
        m = r._mapping
        remaining = int(m["qty_ordered"]) - int(m["packed_qty"])
        lines.append(
            {
                "id": m["id"],
                "product_code": m["product_code"],
                "finish": m["finish"],
                "length_in": m["length_in"],
                "height_in": m["height_in"],
                "qty_ordered": int(m["qty_ordered"]),
                "packed_qty": int(m["packed_qty"]),
                "remaining": remaining,
            }
        )

    line_lookup = {ln["id"]: ln for ln in lines}
    boxes: List[Dict] = []
    for br in db.execute(
        select(
            PackBox.id,
            PackBox.carton_type_id,
            PackBox.custom_l_in,
            PackBox.custom_w_in,
            PackBox.custom_h_in,
            PackBox.weight_lbs,
        )
        .where(PackBox.pack_id == pack_id)
        .order_by(PackBox.id)
    ).all():
        bm = br._mapping
        items: List[Dict] = []
        for ir in db.execute(
            select(PackBoxItem.id, PackBoxItem.order_line_id, PackBoxItem.qty)
            .where(PackBoxItem.pack_box_id == bm["id"])
            .order_by(PackBoxItem.id)
        ).all():
            im = ir._mapping
            ln = line_lookup.get(im["order_line_id"])
            items.append(
                {
                    "id": im["id"],
                    "order_line_id": im["order_line_id"],
                    "product_code": ln["product_code"] if ln else "",
                    "qty": int(im["qty"]),
                }
            )
        label = f'Box #{bm["id"]}'
        if bm["custom_l_in"] and bm["custom_w_in"] and bm["custom_h_in"]:
            label += f' ({bm["custom_l_in"]}x{bm["custom_w_in"]}x{bm["custom_h_in"]} in)'
        boxes.append(
            {
                "id": bm["id"],
                "label": label,
                "weight_lbs": bm["weight_lbs"],
                "items": items,
            }
        )

    header = {
        "order_no": order.order_no,
        "customer_name": order.customer_name,
        "due_date": str(order.due_date) if order.due_date else None,
        "lead_time_plan": order.lead_time_plan,
        "ship_to": order.ship_to,
        "status": pack.status,
    }
    return {"header": header, "lines": lines, "boxes": boxes}

def add_empty_box(db: Session, pack_id: int) -> int:
    pack = db.get(Pack, pack_id)
    if not pack:
        raise ValueError("Pack not found")
    box = PackBox(pack_id=pack_id)
    db.add(box)
    db.commit()
    db.refresh(box)
    return box.id

def assign_one(db: Session, pack_id: int, order_line_id: int, box_id: int) -> None:
    _validate_pack_box_line(db, pack_id, box_id, order_line_id)
    remaining = _remaining_for_line(db, pack_id, order_line_id, exclude_box_id=None)
    if remaining <= 0:
        raise ValueError("No remaining quantity to assign")
    _enforce_pair_rule_on_add(db, pack_id, box_id, order_line_id)
    existing = db.execute(
        select(PackBoxItem).where(
            PackBoxItem.pack_box_id == box_id,
            PackBoxItem.order_line_id == order_line_id,
        )
    ).scalar_one_or_none()
    if existing:
        existing.qty = int(existing.qty) + 1
    else:
        db.add(PackBoxItem(pack_box_id=box_id, order_line_id=order_line_id, qty=1))
    db.commit()

def set_qty(db: Session, pack_id: int, box_id: int, order_line_id: int, qty: int) -> None:
    if qty < 0:
        raise ValueError("Quantity cannot be negative")
    _validate_pack_box_line(db, pack_id, box_id, order_line_id)
    other_sum = _packed_in_pack_excluding_box(db, pack_id, order_line_id, box_id)
    line = db.get(OrderLine, order_line_id)
    if not line:
        raise ValueError("Order line not found")
    ordered = int(line.qty_ordered)
    if other_sum + qty > ordered:
        raise ValueError(f"Exceeds ordered qty ({ordered}); currently {other_sum} in other boxes")
    existing = db.execute(
        select(PackBoxItem).where(
            PackBoxItem.pack_box_id == box_id,
            PackBoxItem.order_line_id == order_line_id,
        )
    ).scalar_one_or_none()
    if (not existing) and qty > 0:
        _enforce_pair_rule_on_add(db, pack_id, box_id, order_line_id)
    if qty == 0:
        if existing:
            db.delete(existing)
            db.commit()
        return
    if existing:
        existing.qty = int(qty)
    else:
        db.add(PackBoxItem(pack_box_id=box_id, order_line_id=order_line_id, qty=int(qty)))
    db.commit()

def remove_box_item(db: Session, pack_id: int, box_item_id: int) -> None:
    item = db.get(PackBoxItem, box_item_id)
    if not item:
        return
    box = db.get(PackBox, item.pack_box_id)
    if not box or box.pack_id != pack_id:
        raise ValueError("Item does not belong to this pack")
    db.delete(item)
    db.commit()

def delete_box_if_empty(db: Session, pack_id: int, box_id: int) -> None:
    box = db.get(PackBox, box_id)
    if not box or box.pack_id != pack_id:
        raise ValueError("Box not found in this pack")
    count = db.execute(
        select(func.count()).select_from(PackBoxItem).where(PackBoxItem.pack_box_id == box_id)
    ).scalar_one()
    if count and int(count) > 0:
        raise ValueError("Cannot delete a non-empty box")
    db.delete(box)
    db.commit()

def set_box_weight_lbs(db: Session, pack_id: int, box_id: int, weight_lbs: int | float | None) -> int | None:
    box = db.get(PackBox, box_id)
    if not box or box.pack_id != pack_id:
        raise ValueError("Box not found in this pack")
    if weight_lbs is None:
        box.weight_lbs = None
        db.commit()
        return None
    rounded = int(ceil(float(weight_lbs)))
    if box.carton_type_id:
        ct = db.get(CartonType, box.carton_type_id)
        if ct and ct.max_weight_lbs is not None and rounded > int(ct.max_weight_lbs):
            raise ValueError(f"Weight exceeds carton max ({ct.max_weight_lbs} lbs)")
    box.weight_lbs = rounded
    db.commit()
    return rounded

# ---------- Internal helpers ----------

def _validate_pack_box_line(db: Session, pack_id: int, box_id: int, order_line_id: int) -> None:
    pack = db.get(Pack, pack_id)
    if not pack:
        raise ValueError("Pack not found")
    box = db.get(PackBox, box_id)
    if not box or box.pack_id != pack_id:
        raise ValueError("Box not found in this pack")
    line = db.get(OrderLine, order_line_id)
    if not line or line.order_id != pack.order_id:
        raise ValueError("Line does not belong to order for this pack")

def _remaining_for_line(db: Session, pack_id: int, order_line_id: int, exclude_box_id: int | None) -> int:
    q = (
        select(func.coalesce(func.sum(PackBoxItem.qty), 0))
        .join(PackBox, PackBox.id == PackBoxItem.pack_box_id)
        .where(PackBox.pack_id == pack_id, PackBoxItem.order_line_id == order_line_id)
    )
    if exclude_box_id is not None:
        q = q.where(PackBoxItem.pack_box_id != exclude_box_id)
    packed = int(db.execute(q).scalar_one() or 0)
    line = db.get(OrderLine, order_line_id)
    if not line:
        raise ValueError("Order line not found")
    ordered = int(line.qty_ordered)
    return ordered - packed

def _packed_in_pack_excluding_box(db: Session, pack_id: int, order_line_id: int, exclude_box_id: int) -> int:
    q = (
        select(func.coalesce(func.sum(PackBoxItem.qty), 0))
        .join(PackBox, PackBox.id == PackBoxItem.pack_box_id)
        .where(
            PackBox.pack_id == pack_id,
            PackBoxItem.order_line_id == order_line_id,
            PackBoxItem.pack_box_id != exclude_box_id,
        )
    )
    return int(db.execute(q).scalar_one() or 0)

def _box_distinct_line_ids(db: Session, box_id: int) -> List[int]:
    rows = db.execute(
        select(PackBoxItem.order_line_id)
        .where(PackBoxItem.pack_box_id == box_id)
        .group_by(PackBoxItem.order_line_id)
    ).all()
    return [int(r[0]) for r in rows]

def _box_id_with_pair_elsewhere(db: Session, pack_id: int, exclude_box_id: int, a_line_id: int, b_line_id: int) -> Optional[int]:
    sub = (
        select(PackBoxItem.pack_box_id.label("box_id"))
        .join(PackBox, PackBox.id == PackBoxItem.pack_box_id)
        .where(PackBox.pack_id == pack_id, PackBoxItem.order_line_id.in_([a_line_id, b_line_id]))
        .group_by(PackBoxItem.pack_box_id)
        .having(func.count(func.distinct(PackBoxItem.order_line_id)) == 2)
    )
    for row in db.execute(sub).all():
        bid = int(row._mapping["box_id"])
        if bid != exclude_box_id:
            return bid
    return None

def _enforce_pair_rule_on_add(db: Session, pack_id: int, dest_box_id: int, new_line_id: int) -> None:
    pack = db.get(Pack, pack_id)
    if not pack:
        raise ValueError("Pack not found")
    order_id = pack.order_id
    existing_line_ids = _box_distinct_line_ids(db, dest_box_id)
    codes = {
        ln.id: ln.product_code
        for ln in db.execute(
            select(OrderLine.id, OrderLine.product_code).where(
                OrderLine.id.in_([new_line_id] + existing_line_ids)
            )
        ).all()
    }
    for other_line_id in existing_line_ids:
        if other_line_id == new_line_id:
            continue
        a, b = sorted((int(new_line_id), int(other_line_id)))
        other_box_id = _box_id_with_pair_elsewhere(db, pack_id, dest_box_id, a, b)
        if other_box_id is not None:
            raise ValueError(
                f"Pair rule: {codes.get(a, a)} + {codes.get(b, b)} already together in Box #{other_box_id}"
            )
        try:
            db.add(PairGuard(order_id=order_id, line_a_id=a, line_b_id=b))
            db.flush()
        except IntegrityError:
            db.rollback()
            # guard already present; allowed for same-box case
