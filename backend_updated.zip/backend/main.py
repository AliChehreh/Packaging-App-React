
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.core.config import get_settings
from backend.api import orders, packs, cartons

settings = get_settings()

app = FastAPI(title="Dayus Packaging App Backend")

# CORS for Vite dev & typical local hosts
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health() -> str:
    return "ok"

# Mount routers
app.include_router(orders.router, prefix="/api")
app.include_router(packs.router, prefix="/api")
app.include_router(cartons.router, prefix="/api")
