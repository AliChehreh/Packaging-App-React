
from fastapi import APIRouter

router = APIRouter(tags=["cartons"])

@router.get("/cartons/health")
def cartons_health():
    return {"ok": True}
