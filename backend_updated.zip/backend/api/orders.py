
from datetime import date, datetime
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import or_, desc, asc, func
from sqlalchemy.orm import Session

from backend.db.session import get_app_session
from backend.db.models import Order as OrderModel, OrderLine as OrderLineModel, Pack as PackModel
from backend.db.oes_read import fetch_order_from_oes
from backend.services.orders import ensure_order_in_app

router = APIRouter(tags=["orders"])

class OrderLineOut(BaseModel):
    id: int
    product_code: str
    length_in: int
    height_in: int
    finish: Optional[str] = None
    qty_ordered: int

    class Config:
        from_attributes = True

class OrderOut(BaseModel):
    id: int
    order_no: str
    customer_name: Optional[str] = None
    ship_to: Optional[str] = None
    due_date: Optional[date] = None
    lead_time_plan: Optional[str] = None
    source: Optional[str] = "OES"
    created_at: Optional[datetime] = None
    total_lines: int = 0
    total_qty: int = 0

    class Config:
        from_attributes = True

@router.get("/orders")
def list_orders(
    q: Optional[str] = Query(None),
    date_from: Optional[date] = Query(None),
    date_to: Optional[date] = Query(None),
    sort: Optional[str] = Query(None, description="e.g. -created_at, created_at, -due_date"),
    limit: int = Query(500, ge=1, le=2000),
    db: Session = Depends(get_app_session),
) -> List[OrderOut]:
    qry = db.query(OrderModel)
    if q:
        like = f"%{q}%"
        qry = qry.filter(or_(OrderModel.order_no.ilike(like), OrderModel.customer_name.ilike(like)))
    if date_from:
        qry = qry.filter(OrderModel.created_at >= datetime.combine(date_from, datetime.min.time()))
    if date_to:
        qry = qry.filter(OrderModel.created_at <= datetime.combine(date_to, datetime.max.time()))
    if sort:
        direction = desc if sort.startswith('-') else asc
        field = sort.lstrip('+-')
        if field == "created_at":
            qry = qry.order_by(direction(OrderModel.created_at))
        elif field == "due_date":
            qry = qry.order_by(direction(OrderModel.due_date))
        elif field == "order_no":
            qry = qry.order_by(direction(OrderModel.order_no))
        elif field == "id":
            qry = qry.order_by(direction(OrderModel.id))
    else:
        qry = qry.order_by(OrderModel.created_at.desc())
    items = qry.limit(limit).all()

    # attach totals
    result: List[OrderOut] = []
    for o in items:
        lines = db.query(OrderLineModel).filter(OrderLineModel.order_id == o.id).all()
        out = OrderOut.model_validate(o)
        out.total_lines = len(lines)
        out.total_qty = sum(int(getattr(ln, "qty_ordered", 0) or 0) for ln in lines)
        result.append(out)
    return result

@router.get("/orders/{order_no}")
def get_order(order_no: str, db: Session = Depends(get_app_session)) -> OrderOut:
    order = db.query(OrderModel).filter(OrderModel.order_no == order_no).one_or_none()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    lines = db.query(OrderLineModel).filter(OrderLineModel.order_id == order.id).all()
    out = OrderOut.model_validate(order)
    out.total_lines = len(lines)
    out.total_qty = sum(int(getattr(ln, "qty_ordered", 0) or 0) for ln in lines)
    return out

@router.get("/orders/{order_no}/lines", response_model=List[OrderLineOut])
def get_order_lines(order_no: str, db: Session = Depends(get_app_session)) -> List[OrderLineOut]:
    order = db.query(OrderModel).filter(OrderModel.order_no == order_no).one_or_none()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    rows = (
        db.query(OrderLineModel)
        .filter(OrderLineModel.order_id == order.id)
        .order_by(OrderLineModel.id.asc())
        .all()
    )
    return [OrderLineOut.model_validate(ln) for ln in rows]

class SyncOrderRequest(BaseModel):
    order_no: str

@router.post("/orders/sync", response_model=OrderOut)
def sync_order(req: SyncOrderRequest, db: Session = Depends(get_app_session)) -> OrderOut:
    try:
        order = ensure_order_in_app(db, req.order_no)
    except ValueError:
        raise HTTPException(status_code=404, detail="Order not found in OES")
    lines = db.query(OrderLineModel).filter(OrderLineModel.order_id == order.id).all()
    out = OrderOut.model_validate(order)
    out.total_lines = len(lines)
    out.total_qty = sum(int(getattr(ln, "qty_ordered", 0) or 0) for ln in lines)
    return out

@router.get("/oes/orders/{order_no}")
def preview_oes_order(order_no: str):
    header, lines = fetch_order_from_oes(order_no)
    if not header:
        raise HTTPException(status_code=404, detail="Order not found in OES")
    return {"header": header, "lines": lines}
