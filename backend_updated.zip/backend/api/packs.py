
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import select

from backend.db.session import get_app_session
from backend.db.models import Order as OrderModel, Pack as PackModel, PackBox as PackBoxModel, PackBoxItem as PackBoxItemModel, OrderLine as OrderLineModel
from backend.services.orders import ensure_order_in_app
from backend.services.pack_view import get_pack_snapshot, add_empty_box, assign_one, set_qty, remove_box_item, delete_box_if_empty, set_box_weight_lbs

router = APIRouter(tags=["packs"])

class StartPackBody(BaseModel):
    order_no: str

@router.post("/pack/start")
def start_pack(body: StartPackBody, db: Session = Depends(get_app_session)):
    order = ensure_order_in_app(db, body.order_no)
    existing = db.execute(
        select(PackModel).where(PackModel.order_id == order.id, PackModel.status == "in_progress")
    ).scalar_one_or_none()
    if existing:
        pid = existing.id
    else:
        pack = PackModel(order_id=order.id, status="in_progress")
        db.add(pack)
        db.commit()
        db.refresh(pack)
        pid = pack.id
    return {"pack_id": int(pid)}

@router.get("/pack/{pack_id}")
def get_pack(pack_id: int, db: Session = Depends(get_app_session)):
    return get_pack_snapshot(db, pack_id)

class AssignOneBody(BaseModel):
    order_line_id: int = Field(..., gt=0)

@router.post("/pack/{pack_id}/assign-one")
def assign_one_endpoint(pack_id: int, body: AssignOneBody, db: Session = Depends(get_app_session)):
    assign_one(db, pack_id, body.order_line_id, _ensure_first_box(db, pack_id))
    return get_pack_snapshot(db, pack_id)

def _ensure_first_box(db: Session, pack_id: int) -> int:
    box = db.execute(select(PackBoxModel).where(PackBoxModel.pack_id == pack_id).order_by(PackBoxModel.id.asc())).scalar_one_or_none()
    if box:
        return int(box.id)
    new_id = add_empty_box(db, pack_id)
    return int(new_id)

class SetQtyBody(BaseModel):
    order_line_id: int = Field(..., gt=0)
    box_id: int = Field(..., gt=0)
    qty: int = Field(..., ge=0)

@router.post("/pack/{pack_id}/set-qty")
def set_qty_endpoint(pack_id: int, body: SetQtyBody, db: Session = Depends(get_app_session)):
    set_qty(db, pack_id, body.box_id, body.order_line_id, body.qty)
    return get_pack_snapshot(db, pack_id)

class RemoveItemBody(BaseModel):
    box_item_id: int = Field(..., gt=0)

@router.delete("/pack/{pack_id}/items/{box_item_id}")
def remove_item(pack_id: int, box_item_id: int, db: Session = Depends(get_app_session)):
    remove_box_item(db, pack_id, box_item_id)
    return get_pack_snapshot(db, pack_id)

class NewBoxBody(BaseModel):
    pass

@router.post("/pack/{pack_id}/boxes")
def create_empty_box_endpoint(pack_id: int, db: Session = Depends(get_app_session)):
    add_empty_box(db, pack_id)
    return get_pack_snapshot(db, pack_id)

@router.delete("/pack/{pack_id}/boxes/{box_id}")
def delete_box_endpoint(pack_id: int, box_id: int, db: Session = Depends(get_app_session)):
    delete_box_if_empty(db, pack_id, box_id)
    return get_pack_snapshot(db, pack_id)

class SetWeightBody(BaseModel):
    weight_lbs: Optional[float] = None

@router.put("/pack/{pack_id}/boxes/{box_id}/weight")
def set_weight_endpoint(pack_id: int, box_id: int, body: SetWeightBody, db: Session = Depends(get_app_session)):
    set_box_weight_lbs(db, pack_id, box_id, body.weight_lbs)
    return get_pack_snapshot(db, pack_id)
